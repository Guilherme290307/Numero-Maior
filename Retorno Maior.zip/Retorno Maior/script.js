let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let btMaior = document.querySelector("#btMaior");
let Resultado = document.querySelector("#Resultado");

function Maior() {
    let num1 = Number(Valor1.value);
    let num2 = Number(Valor2.value);

    
    if (num1 > num2) {
        Resultado.textContent = `${num1}`;
    } else if (num1 < num2) {
        Resultado.textContent = `${num2}`;
    } else {
        Resultado.textContent = "Os dois valores são iguais.";
    }
}

btMaior.onclick = function() {
    Maior();
}